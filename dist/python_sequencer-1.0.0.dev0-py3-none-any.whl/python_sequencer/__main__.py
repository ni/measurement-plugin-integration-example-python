from python_sequencer import run_script

run_script()
