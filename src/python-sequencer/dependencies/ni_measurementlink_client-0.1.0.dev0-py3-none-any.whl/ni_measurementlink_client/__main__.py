""""Creates a measurement client through use of template.py."""

from ni_measurementlink_client.template import create_client

create_client()
